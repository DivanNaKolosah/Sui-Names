package client

import "fmt"

const (
	ErrTableItemNotFound = "table_item_not_found"
	ErrAccountNotFound   = "account_not_found"
	ErrModuleNotFound    = "module_not_found"
)

type Error struct {
	StatusCode  int    `json:"status_code"`
	Message     string `json:"message"`
	ErrorCode   string `json:"error_code"`
	VMErrorCode int    `json:"vm_error_code"`
}

func (e *Error) Error() string {
	return fmt.Sprintf("%s: %s", e.ErrorCode, e.Message)
}

func (e *Error) IsErrorCode(code string) bool {
	return e.ErrorCode == code
}

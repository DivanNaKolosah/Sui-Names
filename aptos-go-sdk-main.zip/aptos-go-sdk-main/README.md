# Aptos Go SDK

[![License](https://img.shields.io/badge/license-mit-green.svg)](https://github.com/portto/aptos-go-sdk/blob/main/LICENSE)

## Install

```sh
go get -v github.com/portto/aptos-go-sdk
```